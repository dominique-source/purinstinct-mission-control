# CODEX — PürInstinct Mission Control / Simulateur financier Écoles

Repository: dominique-source/purinstinct-mission-control
Target: feature branch, PR into main. Do not deploy or merge without approval.

## Mission
Implement a PRIVATE, visually driven, French-Canadian school event financial simulator inside the existing Mission Control app. Inspect the actual current repository, navigation, styling, auth and persistence before editing. Preserve all existing mission tracking and localStorage data. Do not rebuild the application or change existing pages beyond a minimal navigation entry.

## Security is a release blocker
The repository README documents NO authentication and browser localStorage. Do not claim a hidden menu or unlinked route is private. The repository is PUBLIC. Never commit actual customer financial data or credentials. Implement server-side access control on the new route and any APIs using the app's existing auth if present; otherwise use an established production-grade authentication provider and documented configuration. Do not ship the simulator accessible anonymously. If credentials/provider cannot be configured, implement the module behind a server-enforced disabled-by-default feature gate, document setup, and DO NOT deploy it publicly. Never use NEXT_PUBLIC_ for secrets. Check Vercel preview protection too. Avoid exposing financial data in public static assets.

## UX and navigation
Mission Control → Finances → Simulateur Écoles. Match the ACTUAL current visual design, fonts, color tokens, responsive layout, navigation and interactions. Premium PürInstinct style, large titles and totals, restrained copy, very few visible inputs. No spreadsheet UI. French (Québec), CAD. Accessible on iPhone and desktop. Provide three progressive views: (1) MON ÉVÉNEMENT: simple controls, (2) MON RÉSULTAT: production cost, proposed school price, gross margin in $ and %, (3) MA VISION 3 ANS: years 1–3 side by side. Put detailed cost breakdown behind an expandable panel. No charts if they distract. Keep editable inputs clearly distinguished from calculated outputs. Explicitly label assumptions and estimates.

## Calculation model
Use typed pure functions, tests and single source of truth. No fixed price per pupil. Students count is for planning/capacity only, not price driver. Default editable labor COST: 100 CAD/hour per PürInstinct worker. Separate cost from selling price and conference list price. Formula: event staff cost = required PI staff × paid hours × 100; costs = sum of all line items; proposed price = costs/(1-target gross margin decimal), with safe handling of margin >= 100%. Gross margin dollars = price - costs; gross margin percent = (price-costs)/price. User may override proposed price, and margin then recalculates. Clearly distinguish costs and prices; avoid double-counting installation labor.

Reference scenario Year 1: 15 activity zones + 2 PürInstinct courts = 17 activity stations; 15 stations run by school, 2 remaining station leaders supplied by PI PLUS 2 event coordinators = 4 PI staff if each station needs one leader. Prior discussions used 5 PI staff; this is a separate explicitly editable assumption, not an automatic truth. Show a warning when staff assumptions don't reconcile. Capacity: 15 zones × (6 active + 6 next) = 180; 2 courts × (14 active + 14 next) = 56; total 236 simultaneous (118 active + 118 next). For 2,000 students: ceil(2000/236)=9 waves minimum, subject to duration, transitions and operating schedule. Do not assert one-day feasibility without checking actual duration.

Historical illustrative Y1 cost model, using 5 staff × 8 hours at 100 CAD/h: conference internal cost 1,000 (LIST VALUE 2,000, not internal cost), clinics 12h ×100=1,200, teacher training 3h ×100=300, Games staff 5×8×100=4,000, transport/equipment 1,000, installation/production 600, DJ/sound 650, balls left with school 300, administration/app 400. Total 9,450. Illustrative selling price 14,500, gross profit 5,050, margin 34.8276%. All amounts estimates, not verified vendor costs. Installation 600 may overlap with staff hours; flag for review. Clinic hours are aggregate billable worker hours, not necessarily clock hours.

Illustrative Year 2: clinics 6×100=600; training 1.5×100=150; staff 4×8×100=3,200; transport 1,000; installation 600; DJ 650; admin/app 400 => 6,600; price 10,500; gross profit 3,900. Year 3: clinics 3×100=300; staff 3×8×100=2,400; transport 1,000; installation 600; DJ 650; admin/app 400 => 5,350; price 8,500; gross profit 3,150. Conference returns roughly every three years, usually year 4 after the initial year. More teacher participation can lower PI staffing, but PI remains responsible for event production. Do not force a year 2/3 staffing decrease; make editable.

Defaults for an example may use 2,000 students, 15 activity zones, 2 courts, 15 teachers, 5 PI workers, 8h Games, and the figures above, but label it SAMPLE, not an operational guarantee. Allow editing: student count, zone count, court count, teachers available, PI staff count, hours, clinic hours, teacher training hours, conference on/off, transport, installation, DJ, balls, admin, margin target, price override, days/waves and year-specific overrides. Show only 5-6 primary controls initially; use Advanced for the rest. A calculator may derive minimum staffing from stations - teachers + coordinators but must allow explicit staffing override and clearly show the difference. Validate nonnegative inputs and zero-price cases.

## Persistence and data safety
Use a NEW versioned namespace for simulator drafts, never overwrite `purinstinct-mission-control-v1`. Local drafts are acceptable only AFTER access control, with clear note they are device-specific. Offer reset-to-default with confirmation, and optionally export/import JSON with schema validation. No external analytics or third-party data transmission. Avoid storing personally identifiable student data.

## Implementation quality
Use existing Next App Router, TS, React, Tailwind and Lucide. Match project patterns and styling. Add pure finance functions and tests for all numbers above, staffing/capacity/waves, margin override, invalid input, years 1–3 and persistence migration. Test `npm run lint`, `npm run typecheck`, `npm test`, `npm run build`; fix errors. Verify desktop and mobile, no horizontal overflow, keyboard access, focus states. Update README with navigation, defaults, access-control configuration, how to test and deployment safety. Open PR with screenshots and checklist; no merge/deploy without explicit approval.

## Acceptance criteria
- Current Mission Control remains intact, including saved missions.
- New route integrated seamlessly and secured on the SERVER.
- One-screen simple simulator, with advanced cost detail optional.
- All scenario totals match the reference examples when inputs match.
- No per-student billing assumption.
- School involvement and staffing drive cost.
- Three-year view supports different inputs and school pricing per year.
- Public anonymous access is denied, not merely hidden in navigation.
- Tests pass and PR is ready for review.
